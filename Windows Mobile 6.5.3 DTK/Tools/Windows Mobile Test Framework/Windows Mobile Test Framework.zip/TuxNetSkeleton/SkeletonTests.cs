#region usings

using System;
using System.Data;
using Microsoft.MobileDevices.TuxNet;
using Microsoft.MobileDevices.TuxNet.Core;

using Datk          = Microsoft.WindowsCE.Datk;
using Log           = Microsoft.WindowsCE.Logging;
using Products      = Microsoft.MobileDevices.TuxNet.MobileDevicesDescriptorAttribute.Products;
using Skus          = Microsoft.MobileDevices.TuxNet.MobileDevicesDescriptorAttribute.Skus;
using Mtk           = Microsoft.MobileDevices.MobilityToolKit;
#endregion


namespace Microsoft.MobileDevices.Tests.TuxNetSkeleton
{
    /// <summary>
    /// Inbox test suite
    /// </summary>
    public class TuxNetSkeletonTests : TestSuite
    {

        #region Constructors
        /// <summary>
        /// Create new suite
        /// </summary>
        /// <param name="harness">IHarness interface passed in by the harness
        /// this allows access to the "User" param</param>
        public TuxNetSkeletonTests(ITestHarness harness) : base(harness)
        {  
            /*
             * Here is an example of how to pass parms from the harness cmd line to this test assembly.
             *
            
            //If the protocol specified by -user is valid, then set it
            if ((harness.User.IndexOf("customParamYouDefine") != -1))  
            {
                this.someMemberVar = harness.User;
            }
            
            
            */            
        }
        #endregion

        #region Begin/End
        /// <summary>
        /// Setup the suite, create the Visual Diff
        /// </summary>
        public override void Begin()
        {            
            //TODO: Add code to init private data memebers here.
            //This method gets called once before each suite is run.
        }

        /// <summary>
        /// End the suite.  Delete accounts
        /// </summary>
        public override void End()
        {
            //TODO: Add common code to end the suite
        }
        #endregion
        
        #region TuxNetSkeleton Functional test cases
        
        /// <summary> 
        /// Add a description of the steps this test executes.
        /// NOTE: This test case will only run on a Pocket PC phone. 
        /// Look at the MobileDevicesDescriptor attributes to see how this is set.
        /// </summary>
        /// <returns>LogResult.Pass on success</returns>
        [TestCaseAttribute("Title of the test case", Type = TestType.Functional,
        Groups = new string [] {TestGroupNames.Boundary})]
        [MobileDevicesDescriptor ( Product = Products.PocketPC,  Sku = Skus.Gsm | Skus.Cdma) ]        
        public Log.LogResult FunctionalCase1() //TODO: Replace method name FunctionalCase1 with something more meaningful
        {
            Log.LogResult result = Log.LogResult.Fail;             
            //TODO: Add test case steps here            
            Utils.GlobalLogger.AddComment("log something for each step of the test");
            return result;
        }

        /// <summary>     
        /// Add a description of the steps this test executes.    
        /// </summary>
        /// <returns>LogResult.Pass on success</returns>
        [TestCaseAttribute("Title of the test case", Type = TestType.Functional,
        Groups = new string [] {TestGroupNames.Invalid})]
        [TestCaseCleanupAttribute("End")] 
        public Log.LogResult FunctionalCase2() //TODO: Replace method name FunctionalCase2 with something more meaningful
        {
            Log.LogResult result = Log.LogResult.Fail;             
            //TODO: Add test case steps here    
            Utils.GlobalLogger.AddComment("log something for each step of the test");
            return result;
        }       
        #endregion

        #region BVT (Build Verification Test)

        /// <summary>
        /// Add a description of the steps this test executes.
        /// eg: 
        /// 1) Open Contact app
        /// 2) Create a Contact
        /// 3) Verify contact appeats in Main list view
        /// 4) Close Contacts app 
        /// </summary>
        /// <returns>Log.LogResult.Pass on success</returns>
        [TestCaseAttribute("BVT", Type = TestType.BVT)]                     
        public Log.LogResult TuxNetSkeletonBVT() 
        {                        
            Log.LogResult result = Log.LogResult.Fail;             
            //TODO: Add test case steps here   
            Utils.GlobalLogger.AddComment("log something for each step of the test");         
            return result;
        }        
        #endregion

        #region Private Data
        #endregion 
    }


    /// <summary>
    /// List of predefined group names.    
    /// </summary>
    public class TestGroupNames
    {
        //TODO: Change these group names to be more meaningful to your test suite.

        /// <summary>Invalid test cases</summary>
        public const string Invalid     = "InvalidCases";

        /// <summary>Boundary test cases</summary>
        public const string Boundary    = "Boundary";
    }

}
