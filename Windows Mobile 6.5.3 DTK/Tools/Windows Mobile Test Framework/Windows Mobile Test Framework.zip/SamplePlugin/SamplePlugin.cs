using System;
using System.Reflection;
using System.Collections;
using Microsoft.MobileDevices.TuxNet.Core;
using Logging = Microsoft.WindowsCE.Logging;

namespace Microsoft.MobileDevices.TuxNet
{
    /// <summary>
    /// Summary description for Class1.
    /// </summary>
    public class SamplePlugin : ITestHarnessPlugin
    {
        /// <summary>
        /// Registers for test notifications
        /// </summary>
        /// <param name="testEventWatcher"></param>
        public void Initialize(TestEventWatcher testEventWatcher)
        {
            testEventWatcher.OnBeginTestRun     += new TestEventWatcher.BeginTestRunHandler(this.OnBeginTestRun);
            testEventWatcher.OnEndTestRun       += new TestEventWatcher.EndTestRunHandler(this.OnEndTestRun);

            testEventWatcher.OnBeginTestSuite   += new TestEventWatcher.BeginTestSuiteHandler(this.OnBeginTestSuite);
            testEventWatcher.OnEndTestSuite     += new TestEventWatcher.EndTestSuiteHandler(this.OnEndTestSuite);
            
            testEventWatcher.OnBeginTestCase    += new TestEventWatcher.BeginTestCaseHandler(this.OnBeginTestCase);
            testEventWatcher.OnEndTestCase      += new TestEventWatcher.EndTestCaseHandler(this.OnEndTestCase);

            testEventWatcher.OnException        += new TestEventWatcher.ExceptionHandler(this.OnException);
        }

        /// <summary>
        /// Initialize CeStress
        /// </summary>
        /// <param name="assembly"></param>
        public void OnBeginTestRun(System.Reflection.Assembly assembly)
        {
            return;
        }
        /// <summary>
        /// Report results to CeStress
        /// </summary>
        /// <param name="assembly"></param>
        public void OnEndTestRun(System.Reflection.Assembly assembly)
        {            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="suite"></param>
        public void OnBeginTestSuite(ITestSuite suite)
        {
            return;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="suite"></param>
        public void OnEndTestSuite(ITestSuite suite)
        {
            return;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="method"></param>
        public void OnBeginTestCase(MethodInfo method)
        {
            return;
        }
        /// <summary>
        /// Accumulate test result
        /// </summary>
        /// <param name="method"></param>
        /// <param name="testResult"></param>
        public void OnEndTestCase(MethodInfo method, Logging.LogResult testResult)
        {
            return;
        }

        /// <summary>
        /// Handle test exceptions
        /// </summary>
        /// <param name="method"></param>
        /// <param name="e"></param>
        public void OnException(MethodInfo method, System.Exception e)
        {
            return;
        }
    }
}
