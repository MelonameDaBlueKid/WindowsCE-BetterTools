using System;
using System.Data;
using Microsoft.MobileDevices.TuxNet;
using Microsoft.MobileDevices.TuxNet.Core;
using Logging = Microsoft.WindowsCE.Logging;
using Microsoft.MobileDevices.Utils;
using System.Collections;

namespace Microsoft.MobileDevices.TuxNet.Samples
{
    /// <summary>
    /// Simple TestSuite showing the bare minimum requirements for a suite
    /// </summary>
    public class Simple : ITestSuite
    {
        #region ITestSuite methods
        /// <summary>
        /// Initiaize test here
        /// </summary>
        public void Begin()
        {
            //initialize test stuff here
        }
        /// <summary>
        /// Clean up after test
        /// </summary>
        public void End()
        {
            //clean up test stuff here
        }
        #endregion

        #region Sample TestCase
        /// <summary>
        /// Sample Test Case
        /// </summary>
        /// <returns>Test Result</returns>
        [TestCaseAttribute( "Write a description of the test case here", Type = TestType.BVT )]
        public Logging.LogResult Test1()
        {
            //write your test code here
            GlobalLogger.AddComment("Inside Test1");

            //It's okay to just throw exceptions on failure
            //the harness will treat it as returning LogResult.Fail

            //return the results of the test
            return Logging.LogResult.Pass;
        }
        #endregion
    }
    
    /// <summary>
    /// SampleTestSuite showig various options available
    /// this inherits from TestSuite to make pick up be written ITestSuite methods
    /// </summary>
    [TestCaseInitAttribute( "DefaultInit" )]
    [TestCaseCleanupAttribute( "DefaultCleanUp" )]
    public class SampleTestSuite : TestSuite
    {
        /// <summary>
        /// Constructor that takes an interface for calback into the harness
        /// </summary>
        /// <param name="harness"></param>
        public SampleTestSuite(ITestHarness harness) : base(harness)
        {}

        #region ITestSuite methods
        /// <summary>
        /// Initiaize test here
        /// </summary>
        public override void Begin()
        {
            //call the base class first
            base.Begin();

            //then do our own thing
            GlobalLogger.AddComment( "user data recieved: {0}", this.harness.User);
            GlobalLogger.AddComment( "generating some random data: {0}", this.rand.Next());
        }      
        #endregion

        
        /// <summary>
        /// Sample Test Case
        /// </summary>
        /// <returns>Test Result</returns>
        [TestCaseAttribute( "description Test1", Type = TestType.BVT, ID = 42 )]
        public Logging.LogResult Test1()
        {
            GlobalLogger.AddComment("inside Test1");
            return Logging.LogResult.Pass;
        }

        /// <summary>
        /// Sample Test Case
        /// </summary>
        /// <returns>Test Result</returns>
        [TestCaseAttribute( "description Test2", Type = TestType.Functional )]
        public Logging.LogResult Test2()
        {
            GlobalLogger.AddComment("inside Test2");
            return Logging.LogResult.Fail;
        }


        
        /// <summary>
        /// Sample Test Case assigned to a single Group
        /// </summary>
        /// <returns>Test Result</returns>
        [TestCaseAttribute( "Sample for Test Group Attribute", Type = TestType.BVT,
             Groups = new string [] {TestGroupNames.MyGroup1})]
        public Logging.LogResult TestGroup1()
        {
            GlobalLogger.AddComment("executing TestGroup1");
            return Logging.LogResult.Pass;
        }
        /// <summary>
        /// Sample Test Case assigned to 2 Groups
        /// </summary>
        /// <returns>Test Result</returns>
        [TestCaseAttribute( "Sample for Test Group Attribute", Type = TestType.BVT,
             Groups = new string []
             {  TestGroupNames.MyGroup1,
                TestGroupNames.MyGroup2
             }
         )]
             public Logging.LogResult TestGroup2()
        {
            GlobalLogger.AddComment("executing TestGroup2");
            return Logging.LogResult.Pass;
        }

        #region Init and CleanUp sample
        /// <summary>
        /// Sample Test Case demonstrating init and cleanup methods which will 
        /// be called before a test begins and after a test finishes respectively, even if it throws an exception
        /// </summary>
        /// <returns>Test Result</returns>
        [TestCaseAttribute( "description Test1", Type = TestType.Functional )]            
        [TestCaseInitAttribute( "Init" )]
        [TestCaseCleanupAttribute( "CleanUp" )]
        public Logging.LogResult InitAndCleanupSample()
        {
            GlobalLogger.AddComment("inside InitAndCleanupSample");
                        
            //force a failure by throwing an exception just to demo the Init and Cleanup attributes
            throw new System.Exception("Throw an exception just to demo Init and Cleanup");
        }

        /// <summary>
        /// Init method called before test is invoked.
        /// This method must return void and take no parameters
        /// </summary>
        public void Init()
        {
            GlobalLogger.AddComment("Inside Init method");
            return;
        }
        
        /// <summary>
        /// Clean up method called after test completes
        /// This method must return void and take no parameters
        /// </summary>
        public void CleanUp()
        {
            GlobalLogger.AddComment("Inside CleanUp method");
            return;
        }
        
        /// <summary>
        /// Init method called before every test is invoked.
        /// </summary>
        public void DefaultInit()
        {
            GlobalLogger.AddComment("Inside DefaultInit method");
            return;
        }
        
        /// <summary>
        /// Clean up method called after every test completes
        /// </summary>
        public void DefaultCleanUp()
        {
            GlobalLogger.AddComment("Inside DefaultCleanUp method");
            return;
        }
        #endregion
        
        /// <summary>
        /// Sample Stress Test, also demonstrates using user data from the command line
        /// </summary>
        /// <returns></returns>
        [TestCaseAttribute( "Sample Stress Test, also demonstrates using user data from the command line", 
             Type = TestType.Stress,
             Weight = .5 )]
        public Logging.LogResult StressTest()
        {
            GlobalLogger.AddComment("inside StressTest");
            
            string user = this.harness.User;

            //default sleep time in seconds
            int sleepTime = 0;
            if(user!="")
            {
                sleepTime = Convert.ToInt32(user);
            }

            for(int i=0;i<sleepTime; i++)
            {
                GlobalLogger.AddComment("Stress Test seconds elapsed {0}", i);
                System.Threading.Thread.Sleep( 1000 );
            }            
            return Logging.LogResult.Pass;
        }

        /// <summary>
        ///  Sample Fault Injection test, passes after 2 executions to demonstrate running a test until it passes
        /// </summary>
        /// <returns></returns>
        [TestCaseAttribute( 
            "Sample Fault Injection test, passes after 2 executions to demonstrate running a test until it passes",
             Type = TestType.Stress )]
        public Logging.LogResult RunUntil()
        {
            GlobalLogger.AddComment("run count = {0}", this.runCount++);
            
            return (runCount > 2) ? Logging.LogResult.Pass : Logging.LogResult.Fail;
        }
        private int runCount = 0;
        //get a reference to the global Random generator
        private RandomGen rand = RandomGen.Rand;
    }

    /// <summary>
    /// Example of a a Suite derived from another Suite to make 
    /// an uber suite containing test cases from both
    /// </summary>
    public class DerivedTestSuite : SampleTestSuite
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="harness"></param>
        public DerivedTestSuite(ITestHarness harness) : base(harness)
        {}

        /// <summary>
        /// Sample Test Case
        /// </summary>
        /// <returns>Test Result</returns>
        [TestCaseAttribute( "description ParentTest", Type = TestType.Functional )]
        public Logging.LogResult ParentTest()
        {
            GlobalLogger.AddComment("inside ParentTest");
            return Logging.LogResult.Fail;
        }
    }

    /// <summary>
    /// Example of a Test Suite passing parameters to test methods 
    /// an uber suite containing test cases from both
    /// </summary>
    public class ParametersSuite : TestSuite
    {
        /// <summary>
        /// Sample Test Case
        /// </summary>
        /// <returns>Test Result</returns>
        [TestCaseAttribute( "Sample passing parameters to a test case", Type = TestType.Functional )]
        [ParameterAttribute( "hello" )]
        public Logging.LogResult TestString(string stringData)
        {
            GlobalLogger.AddComment("inside TestString");
            GlobalLogger.AddComment("stringData = {0}", stringData);
            return Logging.LogResult.Pass;
        }

        /// <summary>
        /// Sample passing int to a test case
        /// </summary>
        /// <param name="intData"></param>
        /// <returns></returns>
        [TestCaseAttribute( "Sample passing int to a test case", Type = TestType.Functional )]
        [ParameterAttribute( 42 )]
        public Logging.LogResult TestInt(int intData)
        {
            GlobalLogger.AddComment("inside TestInt");
            GlobalLogger.AddComment("intData = {0}", intData);
            return Logging.LogResult.Pass;
        } 

        /// <summary>
        /// Sample: passing object to a test case
        /// </summary>
        /// <param name="myData"></param>
        /// <returns></returns>
        [TestCaseAttribute( "Sample: passing object to a test case", Type = TestType.Functional )]
        public Logging.LogResult TestMyData(MyData myData)
        {
            GlobalLogger.AddComment("inside TestMyData");
            GlobalLogger.AddComment("myData = {0}", myData.ToString() );
            return Logging.LogResult.Pass;
        }
    }

    /// <summary>
    /// Sample class for demonstrating passing an object to a test case
    /// </summary>
    public class MyData
    {
        /// <summary>
        /// Empty constructor needed for serialization
        /// </summary>
        public MyData()
        {
            this.StringData = "hello";
            this.IntData = 42;
        }

        /// <summary>
        /// String Data
        /// </summary>
        public string StringData;
        
        /// <summary>
        /// Int Data
        /// </summary>
        public int IntData;

        /// <summary>
        /// Returns data represented as a string for logging
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return this.StringData + ", " + this.IntData.ToString();
        }
    }


    /// <summary>
    /// List of predefined group names
    /// </summary>
    public class TestGroupNames
    {
        /// <summary>Sample Group Name 1</summary>
        public const string MyGroup1 = "MyGroup1";

        /// <summary>Sample Group Name 2</summary>
        public const string MyGroup2 = "MyGroup2";
    }
}
