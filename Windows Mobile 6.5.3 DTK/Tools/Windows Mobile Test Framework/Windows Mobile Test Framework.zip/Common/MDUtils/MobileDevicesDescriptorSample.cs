using System;
using Microsoft.MobileDevices.TuxNet.Core;
using Microsoft.MobileDevices.Utils;
using System.Collections;

namespace Microsoft.MobileDevices.TuxNet
{
    /// <summary>
    /// Mobile Devices attribute for describing devices thattests can be run on.
    /// </summary>
    [AttributeUsage(
         AttributeTargets.Method | AttributeTargets.Class 
         /*| AttributeTargets.Assembly*/, //not supported by harness yet.
         AllowMultiple=false)]    
    public sealed class SampleDescriptorAttribute : DeviceDescriptorAttribute
    {       
        //add whatever constructors and properties you like here...

        #region ITestCaseDeviceAttribute methods
        /// <summary>
        /// Returns true if this test is valid for this device
        /// </summary>
        public override bool IsValidDevice
        {
            get
            {
                //do what ever checks you like here...
                return true;
            }    
        }
        #endregion
    }
}
