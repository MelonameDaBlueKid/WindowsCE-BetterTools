using System;
using Microsoft.MobileDevices.TuxNet.Core;
using Microsoft.MobileDevices.Utils;
using System.Collections;

namespace Microsoft.MobileDevices.TuxNet
{
    /// <summary>
    /// Mobile Devices attribute for describing devices thattests can be run on.
    /// </summary>
    [AttributeUsage(
         AttributeTargets.Method | AttributeTargets.Class 
         /*| AttributeTargets.Assembly*/, //not supported by harness yet.
         AllowMultiple=false)]    
    public sealed class MobileDevicesDescriptorAttribute : DeviceDescriptorAttribute
    {
        #region ITestCaseDeviceAttribute methods
        /// <summary>
        /// Returns true if this test is valid for this device
        /// </summary>
        public override bool IsValidDevice
        {
            get
            {
                return
                    IsValidLanguage() &&
                    IsValid( this.skus, DeviceInfo.Device.SKU) &&
                    IsValid( this.products, DeviceInfo.Device.Product);
            }    
        }
        #endregion
       
        #region public properties
        /// <summary>
        /// List of Valid Products
        /// </summary>
        public Products Product
        {
            get
            {
                return this.products;
            }
            set
            {
                this.products = value;
            }
        }
        /// <summary>
        /// List of Valid Skus
        /// </summary>
        public Skus Sku
        {
            get
            {
                return this.skus;
            }
            set
            {
                this.skus = value;
            }
        }

        /// <summary>Valid Languages</summary>
        public int [] Languages
        {
            get
            {
                return (int []) this.languages.ToArray(typeof(int));
            }
            set
            {                
                this.languages = new ArrayList();
                this.languages.AddRange(value);
            }
        } 
        #endregion

        #region enums
        /// <summary>Valid Products</summary>
        [FlagsAttribute]            
        public enum Products
        {
            /// <summary>PocketPC</summary>
            PocketPC = 0x1,
            /// <summary>SmartPhone</summary>
            SmartPhone = 0x2,
        }

        /// <summary>Valid Skus</summary>
        [FlagsAttribute]
        public enum Skus
        {
            /// <summary>Standard</summary>
            Standard = 0x1,
            /// <summary>ShellOnly (PPC_Entry)</summary>
            ShellOnly = 0x2,
            /// <summary>Premium</summary>
            Premium = 0x4,
            /// <summary>Gsm</summary>
            Gsm = 0x8,
            /// <summary>Cdma</summary>
            Cdma = 0x10,
        }
        #endregion

        #region privates
        private bool IsValidLanguage()
        {
            bool result = false;

            //if no languages are specified then 
            //anything goes...
            if( this.Languages.Length == 0 )
            {
                result = true;
            }
            else
            {
                //convert the language we get from DeviceInfo
                //into an int and see if it's in the list.
                int lcid = Convert.ToInt32(DeviceInfo.Device.Language);
                result = this.languages.Contains(lcid);
            }
            return result;
        }

        private bool IsValid( object items, string compare)
        {
            Type type = items.GetType();
            bool result = false;

            //for every bit value
            for(int i=1; i < int.MaxValue; i = i << 1)
            {
                //if it's not a valid enum then bail out.
                if(!Enum.IsDefined(type,i))
                {
                    break;
                }
                //convert the int into an enum and then get the string
                string item = Enum.ToObject(type, ((int) items & i) ).ToString().ToLower();
                
                //see if it compares to the string provided.
                if( item == compare.ToLower())
                {
                    //WooHoo! This check passes.
                    result = true;
                    break;
                }
            }
            return result;
        }

        private Products  products  = (Products)  ~0;
        private Skus      skus      = (Skus)      ~0;
        private ArrayList languages = new ArrayList();
        private DeviceInfo device = DeviceInfo.Device;
        #endregion
    }
}
