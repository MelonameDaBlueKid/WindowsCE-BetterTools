#region usings

using System;
using System.Data;
using Microsoft.MobileDevices.TuxNet;
using Microsoft.MobileDevices.TuxNet.Core;

using Datk          = Microsoft.WindowsCE.Datk;
using Log           = Microsoft.WindowsCE.Logging;
using Utils         = Microsoft.MobileDevices.Utils;
using Mtk           = Microsoft.MobileDevices.MobilityToolKit;
using CalViewAreaLib = Microsoft.MobileDevices.AreaLibrary.CalView.AreaLibraryManager;

#endregion


namespace Microsoft.MobileDevices.Tests.CalView
{
    /// <summary>
    /// Inbox test suite
    /// </summary>
    public class CalViewTests : TestSuite
    {
        #region Constructors
        /// <summary>
        /// Create new suite
        /// </summary>
        /// <param name="tuxnet">ITestHarness interface passed in by the harness
        /// this allows access to the "User" param</param>
        public CalViewTests(ITestHarness tuxnet)
            : base(tuxnet)
        {
            /*
             * Here is an example of how to pass parms from the Tux.Net cmd line to this test assembly.
             *
            
            //If the protocol specified by -user is valid, then set it
            if ((tuxnet.User.IndexOf("customParamYouDefine") != -1))  
            {
                this.someMemberVar = tuxnet.User;
            }
            
            
            */
        }
        #endregion

        #region Begin/End
        /// <summary>
        /// Setup the suite, create the Visual Diff
        /// </summary>
        public override void Begin()
        {
            Mtk.ApplicationManager.GotoHome();

            //TODO: Add code to init private data memebers here.
            //This method gets called once before each suite is run.
        }

        /// <summary>
        /// End the suite.  Delete accounts
        /// </summary>
        public override void End()
        {
            Mtk.ApplicationManager.GotoHome();

            //TODO: Add common code to end the suite
        }
        #endregion
        
        #region CalView Functional test cases
        
        /// <summary> 
        /// Add a description of the steps this test executes.
        /// NOTE: This test case will only run on a Pocket PC phone. 
        /// Look at the MobileDevicesDescriptor attributes to see how this is set.
        /// </summary>
        /// <returns>LogResult.Pass on success</returns>
        [TestCaseAttribute("Title of the test case", Type = TestType.Functional,
        Groups = new string [] {TestGroupNames.Boundary})]     
        public Log.LogResult FunctionalCase1() //TODO: Replace method name FunctionalCase1 with something more meaningful
        {
            Log.LogResult result = Log.LogResult.Fail;             
            //TODO: Add test case steps here            
            Utils.GlobalLogger.AddComment("log something for each step of the test");
            return result;
        }

        /// <summary>     
        /// Add a description of the steps this test executes.    
        /// </summary>
        /// <returns>LogResult.Pass on success</returns>
        [TestCaseAttribute("Title of the test case", Type = TestType.Functional,
        Groups = new string [] {TestGroupNames.Invalid})]
        [TestCaseCleanupAttribute("End")] 
        public Log.LogResult FunctionalCase2() //TODO: Replace method name FunctionalCase2 with something more meaningful
        {
            Log.LogResult result = Log.LogResult.Fail;             
            //TODO: Add test case steps here    
            Utils.GlobalLogger.AddComment("log something for each step of the test");
            return result;
        }       
        #endregion

        #region BVT (Build Verification Test)

        /// <summary>
        /// Add a description of the steps this test executes.
        /// eg: 
        /// 1) Open Contact app
        /// 2) Create a Contact
        /// 3) Verify contact appeats in Main list view
        /// 4) Close Contacts app 
        /// </summary>
        /// <returns>Log.LogResult.Pass on success</returns>
        [TestCaseAttribute("BVT", Type = TestType.BVT)]                 
        public Log.LogResult CalViewBVT()
        {
            // Open the application
            CalViewAreaLib.General.LaunchApp();

            // Store and log the beginning count 
            int countBefore = CalViewAreaLib.MainDialog.GetItemCount();
            Utils.GlobalLogger.AddComment("countBefore = {0}", countBefore.ToString());

            // Select and copy one of the items
            CalViewAreaLib.MainDialog.SelectItem(0);
            CalViewAreaLib.MainDialog.CopySelectedItem();

            // Store and log the count after copy
            int countAfter = CalViewAreaLib.MainDialog.GetItemCount();
            Utils.GlobalLogger.AddComment("countAfter = {0}", countAfter.ToString());

            // Log a result based on the conditional that countAfter is one greater than countBefore
            Utils.GlobalLogResultManager.Results.Add("Count after is one greater", (countAfter == (countBefore + 1)));

            // Close the app to clean up
            CalViewAreaLib.General.CloseApp();

            // Results manager kept track of the result for you, return its summary
            return Utils.GlobalLogResultManager.Results.Summary; 

        }        
        #endregion

        #region Private Data
        // Add any private data/vars used by your tests here.        
        #endregion 
    }


    /// <summary>
    /// List of predefined group names.    
    /// </summary>
    public class TestGroupNames
    {
        //TODO: Change these group names to be more meaningful to your test suite.

        /// <summary>Invalid test cases</summary>
        public const string Invalid     = "InvalidCases";

        /// <summary>Boundary test cases</summary>
        public const string Boundary    = "Boundary";
    }

}
