//
// (C) Microsoft Corp, 2006
// 

using System;
using Datk  = Microsoft.WindowsCE.Datk;
using Mtk   = Microsoft.MobileDevices.MobilityToolKit;

namespace Microsoft.MobileDevices.AbstractionLayer.CalView.PocketPC
{
    /// <summary>
    /// IdnHolder class holding all the Idn strings for the CalViewMainDialog dialog.
    /// </summary>    
    public class CalViewMainDialogIdnHolder
    {
        // /// <summary>Sample Idn for class CalViewMainDialog.  WWE="WWE Text"</summary>
        // public readonly Mtk.IdnString SampleTextIdn = new Mtk.IdnString(Mtk.ModuleNames.someDll, "SOME_IDN_KEY");

        /// <summary>
        /// Idn for name of CalView application.
        /// </summary>
        public readonly Mtk.IdnString CalViewIdn = new Mtk.IdnString("CalView.exe", "DLG_1000_CAPTION_0");

        /// <summary>
        /// Idn for title of main CalView dialog.
        /// </summary>
        public readonly Mtk.IdnString CalViewMainIdn = new Mtk.IdnString("CalView.exe", "DLG_1000_CAPTION_0");

        /// <summary>
        /// Idn for menu SoftKey. WWE="Menu"
        /// </summary>
        public readonly Mtk.IdnString MenuSoftKeyIdn = new Mtk.IdnString("CalView.exe", "MNU2_101_POPUP0");

        /// <summary>
        /// Idn for menu item. WWE="Refresh"
        /// </summary>
        public readonly Mtk.IdnString MenuRefreshIdn = new Mtk.IdnString("CalView.exe", "MNU2_101_2008");

        /// <summary>
        /// Idn for menu item. WWE="Display"
        /// </summary>
        public readonly Mtk.IdnString MenuDisplayIdn = new Mtk.IdnString("CalView.exe", "MNU2_101_2004");

        /// <summary>
        /// Idn for menu item. WWE="Edit"
        /// </summary>
        public readonly Mtk.IdnString MenuEditIdn = new Mtk.IdnString("CalView.exe", "MNU2_101_2003");

        /// <summary>
        /// Idn for menu item. WWE="Copy"
        /// </summary>
        public readonly Mtk.IdnString MenuCopyIdn = new Mtk.IdnString("CalView.exe", "MNU2_101_2006");

        /// <summary>
        /// Idn for menu item. WWE="Delete"
        /// </summary>
        public readonly Mtk.IdnString MenuDeleteIdn = new Mtk.IdnString("CalView.exe", "MNU2_101_2005");

        /// <summary>
        /// Idn for menu item. WWE="About"
        /// </summary>
        public readonly Mtk.IdnString MenuAboutIdn = new Mtk.IdnString("CalView.exe", "MNU2_101_2007");

        /// <summary>
        /// Idn for menu item. WWE="Exit"
        /// </summary>
        public readonly Mtk.IdnString MenuExitIdn = new Mtk.IdnString("CalView.exe", "MNU2_101_2001");
    }

}
