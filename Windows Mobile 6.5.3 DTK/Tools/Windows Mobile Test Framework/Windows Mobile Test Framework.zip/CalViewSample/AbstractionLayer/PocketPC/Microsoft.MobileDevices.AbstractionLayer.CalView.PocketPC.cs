using System;
using System.Data;
using TuxNet = Microsoft.MobileDevices.TuxNet;
using Logging = Microsoft.WindowsCE.Logging;
using Logger = Microsoft.MobileDevices.Utils.GlobalLogger;
using Mtk = Microsoft.MobileDevices.MobilityToolKit;

namespace Microsoft.MobileDevices.AbstractionLayer.CalView.PocketPC
{
    /// <summary>
    /// Container for CalView application sample UIAL.
    /// </summary>
    public class CalViewApp
    {
        /// <summary>
        /// IdnHolder object holding all the Idn strings for the MainWndDialog
        /// </summary>
        public static readonly CalViewMainDialogIdnHolder CalViewIdns = new CalViewMainDialogIdnHolder();

        static CalViewApp()
        {
        }

        /// <summary>
        /// Launch the CalView application
        /// </summary>
        public static void Launch()
        {
            Mtk.PocketPC.ApplicationManager.LaunchApplication(CalViewIdns.CalViewIdn);
            calViewMainDialog = new CalViewMainDialog();
        }

        /// <summary>
        /// The CalView main dialog
        /// </summary>
        public static CalViewMainDialog CalViewMainDialog
        {
            get
            {
                if ((calViewMainDialog == null) || (!calViewMainDialog.IsValid))
                {
                    calViewMainDialog = new CalViewMainDialog();
                }
                return calViewMainDialog;
            }
        }

       
        static CalViewMainDialog calViewMainDialog;

    }

    /// <summary>
    /// CalView abstraction layer self-test
    /// </summary>
    public class CalViewAbstractionLayerTests : TuxNet.Core.TestSuite
    {
        /// <summary>
        /// Abstraction layer BVT
        /// </summary>
        /// <returns>pass/fail</returns>
        [TuxNet.TestCaseAttribute("Check each control is wrapped successfully", Type = TuxNet.TestType.BVT)]
        public Logging.LogResult AbstractionLayerBVT()
        {
            Logging.LogResult result = Logging.LogResult.Fail;

            #region Open CalView
            Logger.AddComment("Open CalView");
            CalViewApp.Launch();
            #endregion

            #region Verify the Abstraction Layer
            Logger.AddComment("Check all controls In CalView");
            CalViewApp.CalViewMainDialog.VerifyAllControls();
            #endregion

            #region Close CalView
            Mtk.Softkeys.Current.UseRightMenuItem(CalViewApp.CalViewIdns.MenuExitIdn);
            Mtk.ApplicationManager.GotoHome();
            #endregion

            result = Logging.LogResult.Pass;
            return result;
        }
    }
}

