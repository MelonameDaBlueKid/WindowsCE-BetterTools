using System;
using System.Data;
using Datk  = Microsoft.WindowsCE.Datk;
using Mtk   = Microsoft.MobileDevices.MobilityToolKit;
using Utils = Microsoft.MobileDevices.Utils;


namespace Microsoft.MobileDevices.AreaLibrary.CalView
{
      
    /// <summary>
    /// Abstract area library class for application Main window
    /// </summary>   
    public abstract class MainDialog
    {
        #region Infrastructure
        /// <summary>
        /// Host the Singleton
        /// </summary>
        private static MainDialog deviceInstance = null;

        /// <summary>
        /// This static constructor checks the device type and instantiates 
        /// a single instance of the appropriate library specialization the 
        /// first time the MainListView class is referenced.
        /// </summary>
        static MainDialog()
        {
            Utils.DeviceInfo deviceInfo = new Utils.DeviceInfo();            
            if (deviceInfo.IsPocketPC)
            {
                deviceInstance = new MainDialogPocketPC();
            }
            else
            {
                deviceInstance = new MainDialogSmartPhone();
            }
        }

        /// <summary>
        /// Retrieve singleton area libary object
        /// </summary>
        public static MainDialog Instance 
        {
            get {return deviceInstance;}
        }
        
        #endregion Infrastructure
        
        #region Public methods

        /// <summary>
        /// Select item with specified index
        /// </summary>
        /// <param name="index">Index of item to select</param>
        public abstract void SelectItem(int index);
        /// <summary>
        /// Copy selected item to clipboard
        /// </summary>
        public abstract void CopySelectedItem();
        /// <summary>
        /// Get the count of items in the list
        /// </summary>
        /// <returns>Count of items in the list</returns>
        public abstract int GetItemCount();

        #endregion

    }   
}
