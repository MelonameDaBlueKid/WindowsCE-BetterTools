using System;
using System.Data;
using Datk      = Microsoft.WindowsCE.Datk;
using Mtk       = Microsoft.MobileDevices.MobilityToolKit;
using Utils     = Microsoft.MobileDevices.Utils;
using CalViewUial = Microsoft.MobileDevices.AbstractionLayer.CalView.PocketPC;


namespace Microsoft.MobileDevices.AreaLibrary.CalView
{
    /// <summary>
    /// Pocket PC General library functions
    /// </summary>
    internal class GeneralPocketPC : General
    {
        public override void LaunchApp()
        {              
            CalViewUial.CalViewApp.Launch();
        }

        public override void CloseApp()
        {
            Mtk.PocketPC.TaskBar.ClickOK();
        }

        public override void KillApp()
        {
            throw new NotSupportedException ("KillApp() - Not Yet Implemented");
        }
    }
}

