using System;
using System.Data;
using Datk      = Microsoft.WindowsCE.Datk;
using Mtk       = Microsoft.MobileDevices.MobilityToolKit;
using Utils     = Microsoft.MobileDevices.Utils;
using CalViewUial = Microsoft.MobileDevices.AbstractionLayer.CalView.SmartPhone;


namespace Microsoft.MobileDevices.AreaLibrary.CalView
{
    /// <summary>
    /// Smart phone Tasks general library functions
    /// </summary>
    internal class GeneralSmartPhone : General
    {

        public override void LaunchApp()
        {
            CalViewUial.CalViewApp.Launch();
        }

        public override void CloseApp()
        {
            Mtk.Softkeys.Current.UseRightMenuItem(CalViewUial.CalViewApp.CalViewIdns.MenuExitIdn);
        }

        public override void KillApp()
        {
            throw new NotSupportedException ("KillApp() - Not Yet Implemented");
        }
    }
}
