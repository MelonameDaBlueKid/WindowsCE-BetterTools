using System;
using System.Data;
using Datk      = Microsoft.WindowsCE.Datk;
using Mtk       = Microsoft.MobileDevices.MobilityToolKit;
using Utils     = Microsoft.MobileDevices.Utils;
using CalViewUial = Microsoft.MobileDevices.AbstractionLayer.CalView.PocketPC;


namespace Microsoft.MobileDevices.AreaLibrary.CalView
{
    /// <summary>
    /// Pocket PC main dialog 
    /// </summary>
    internal class MainDialogPocketPC : MainDialog
    {        
        #region Public methods

        /// <summary>
        /// Select item with specified index
        /// </summary>
        /// <param name="index">Index of item to select</param>
        public override void SelectItem(int index)
        {
            // Use the down key twice to get focus on the listview items
            Datk.KeyBoard.SendKey(Datk.KeyBoard.Key.Down);
            Datk.KeyBoard.SendKey(Datk.KeyBoard.Key.Down);

            CalViewUial.CalViewApp.CalViewMainDialog.MainListView.SetItemSelected(index, true);
        }

        /// <summary>
        /// Copy selected item to clipboard
        /// </summary>
        public override void CopySelectedItem()
        {
            Mtk.Softkeys.Current.UseRightMenuItem(CalViewUial.CalViewApp.CalViewIdns.MenuCopyIdn);
        }

        /// <summary>
        /// Get the count of items in the list
        /// </summary>
        /// <returns>Count of items in the list</returns>
        public override int GetItemCount()
        {
            int val = -1;
            string labelText = CalViewUial.CalViewApp.CalViewMainDialog.LabelCount.Text;

            if (labelText != null && labelText.Length > 0)
            {
                int index = labelText.IndexOf("=");
                val = int.Parse(labelText.Substring(index + 1));
            }
            return val;
        }

        #endregion

    }
}


