using System;
using System.Data;
using Datk  = Microsoft.WindowsCE.Datk;
using Mtk   = Microsoft.MobileDevices.MobilityToolKit;
using Utils = Microsoft.MobileDevices.Utils;


namespace Microsoft.MobileDevices.AreaLibrary.CalView
{      
    /// <summary>
    /// Abstract area library class for General 
    /// </summary>   
    public abstract class General
    {
        #region Infrastructure
        /// <summary>
        /// Host the Singleton
        /// </summary>
        private static General deviceInstance = null;

        /// <summary>
        /// This static constructor checks the device type and instantiates 
        /// a single instance of the appropriate library specialization the 
        /// first time the General class is referenced.
        /// </summary>
        static General()
        {
            Utils.DeviceInfo deviceInfo = new Utils.DeviceInfo();            
            if (deviceInfo.IsPocketPC)
            {
                deviceInstance = new GeneralPocketPC();
            }
            else
            {
                deviceInstance = new GeneralSmartPhone();
            }
        }

        /// <summary>
        /// Retrieve singleton area libary object
        /// </summary>
        public static General Instance 
        {
            get {return deviceInstance;}
        }
        

        #endregion Infrastructure

        /// <summary>
        /// Launches the Tasks App
        /// </summary>
        public abstract void LaunchApp();
        
        /// <summary>
        /// Closes the Task app
        /// </summary>
        public abstract void CloseApp();        

        
        /// <summary>
        /// Kills the app process. Ensure the app is closed.
        /// </summary>
        public abstract void KillApp();
    }   
}
