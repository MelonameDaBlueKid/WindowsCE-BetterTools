using System;
using System.Data;
using Datk      = Microsoft.WindowsCE.Datk;
using Mtk       = Microsoft.MobileDevices.MobilityToolKit;
using Utils     = Microsoft.MobileDevices.Utils;


namespace Microsoft.MobileDevices.AreaLibrary.CalView
{

    /// <summary>
    /// Area Library Manger which has access to the different dialogs we can access in this app
    /// </summary>
    public sealed class AreaLibraryManager
    {
        private AreaLibraryManager()
        {
        }

        // One of these objects will always be created, 
        // whether you use it or not

        /// <summary>
        /// Creates a general instance
        /// </summary>
        public static General General
        {
            get
            {
                return generalInstance;
            }
        } 

        /// <summary>
        /// MainDialog
        /// </summary>
        public static MainDialog MainDialog
        {
            get
            {
                if(mainDialogInstance == null)
                {
                    mainDialogInstance = MainDialog.Instance;
                }
                return mainDialogInstance;
            }
        }        

        private static General          generalInstance = General.Instance;
        private static MainDialog       mainDialogInstance;        
    }
}